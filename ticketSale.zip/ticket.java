/* Sagun Baral
/2/16/20
/IT-206 
//PROGRAMMING ASSIGNMENT 1 
Description: the program promprs user to enter event name, the capacity of the stadium,whether or not the event is sponsored
and types of tickets for example child, adult or free and calculates total tickets with 
total tickets and total revenue with the help of object-oriented techniques and by the help of variables, accessors,
 mutators, special purpose methods,
 and constructors
 */
public class ticket {
	private String event;//Represent the ticket sale 
	private int capacity;
	private int adultTicket;
	private int childTicket;
	private int freeTicket;

 public ticket (String event, int capacity) {
	       setEvent(event);
	       setCapacity(capacity);
	    }
 

 
public  void saleTicket (int adultTicket,int childTicket,int freeTicket) {
	setAdultTicket(adultTicket);
	setchildTicket(childTicket);
	setfreeTicket(freeTicket);
}

public void setEvent(String event) {
 if (event == null) throw new IllegalArgumentException("Cannot be empty");
 if (event.equals("")) throw new IllegalArgumentException("Cannot be empty "); 
    this.event = event;  
}
private void setCapacity(int capacity) {
    if ((capacity < 0) || (capacity > 5000)) throw new IllegalArgumentException("The capacity is 5000 people and cannot be negetive: ");
    this.capacity = capacity; // sets capacity and throws illegal argument exception if the output is incorrect
}
public void setAdultTicket(int adultTicket) {
 if (adultTicket > 5000) throw new IllegalArgumentException("The stadium only supports 5000 people"); 
	this.adultTicket = adultTicket;// sets adult ticket and throws illegal argument exception if the output is incorrect
}
public void setchildTicket(int childTicket) {
	if ((childTicket + adultTicket) > 5000) throw new IllegalArgumentException("The stadium only supports 5000 people");
	this.childTicket=childTicket;
}
public void setfreeTicket(int freeTicket) {
	if ((childTicket + adultTicket + freeTicket) > 5000) throw new IllegalArgumentException("The stadium only supports 5000 people");
	this.freeTicket=freeTicket;
}
public String getEvent() {
    return this.event;
}
public int getCapacity() {
    return this.capacity;
}
public int getFreeTicket() {
	return this.freeTicket;
}
public int getAdultTicket() {
	return this.adultTicket;
}
public int getchildTicket() {
	return this.childTicket;
}

public String toString() {
	return  "Event Name: "+ this.event + "\n Tickets Sold:" +this.capacity;// passes the event name and capacity of the event
}
}