import javax.swing.JOptionPane;
// this is the main method where the user input gets calculated and displayed
public class totalTicket {
	private static final int MAX = 5000;
    private static int numEvent = 0;
     private static int adultTotal=0;
     private static int childTotal=0;
     private static int freeTotal=0;
     private static int totalTicket=0;
     private static int totalRevenue=0;
     private static int sponserRevenue =0;
	private static ticket theShop;
	public static void main(String[] args) 
	{

        String theName = getStringFromUser("Event Name?");// ask user for event name
        int theStartUpMoney = getIntFromUser("Capacity?");// ask user for capacity
        boolean sponser= getBooleanFromUser("Sponser?");// ask user for sponser
        try {
            theShop = new ticket(theName, theStartUpMoney);
           second();
        } catch (IllegalArgumentException iae) {
             showMessage(iae.getMessage());
        } 
        if (sponser){
         sponserRevenue = (adultTotal + childTotal);}// calculates sponser revenue if there are any sponsers
         String output = theShop.toString();
        output +="\n Adult ticket sold: "+ adultTotal + "\n Child ticket sold: "+ childTotal +"\n Free Ticket sold: "+ freeTotal + "\n Total Ticket sold: "+totalTicket + "\n Total Revenue: $"+ totalRevenue + "\n Sponser Donation: $" + sponserRevenue ;
        // prints out the output
        
       showMessage(output);       
        
    }
    
   
	private static void second()
	{
		int userChoice = 2;
        do {
            userChoice = getChoice();
            if (userChoice == 1) addEvent();
        } while (userChoice != 2);        
    }
	 private static int getChoice() {
	        String prompt = "";
     
	        prompt += "\n";
	        prompt += "1) Enter 1 for sale\n";// gives user options to keep entering or to quit
	        prompt += " 2)  2 to quit\n";

	        return getIntFromUser(prompt);
	    } 
	 private static void addEvent() {
	        if (numEvent < MAX) {
           
	           int theadultTicket = getIntFromUser("Adult tickets?");// ask user for the tickets
	            int childTicket = getIntFromUser("Child tickets?");
	            int freeTicket = getIntFromUser("Free tickets?");
	 
	            
               try {
	                 theShop.saleTicket(theadultTicket,childTicket,freeTicket);
	                  } catch (IllegalArgumentException iae) {
	                showMessage(iae.getMessage()); 
	            }
              
               adultTotal += theShop.getAdultTicket();
               childTotal += theShop.getchildTicket();// adds total tickets
               freeTotal += theShop.getFreeTicket();
               totalTicket= adultTotal+childTotal+freeTotal;
               totalRevenue= (adultTotal*7)+(childTotal*4);

               
	        } else showMessage("Max number of tickets reached"); 
	    }

	

	 public static String getStringFromUser(String userPrompt) {
	        return JOptionPane.showInputDialog(userPrompt);
	    }
       

	    public static int getIntFromUser(String userPrompt) {
	        String stringInput = "";
	        while (true) {
	            try {
	               stringInput = getStringFromUser(userPrompt);
	                int intInput = Integer.parseInt(stringInput);
	                return intInput;
	            } catch (NumberFormatException nfe) {
	                showMessage("Invalid Input: " + stringInput);
	            }
	        }
	    }
       
       
       public static void showMessage(String outputMessage) {
	        JOptionPane.showMessageDialog(null, outputMessage);
	    } 
 public static boolean getBooleanFromUser (String userPrompt) {    
        int result = JOptionPane.showConfirmDialog(null, userPrompt,null,JOptionPane.YES_NO_OPTION);
        return (result == 0); // showConfirmDialog returns 0 for "yes" and 1 for "no"
    }

}
